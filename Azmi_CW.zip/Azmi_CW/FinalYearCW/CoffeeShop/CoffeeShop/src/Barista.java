public class Barista implements Runnable{
    private CoffeeShop coffeeShop;
    public Barista(CoffeeShop coffeeShop){
        this.coffeeShop = coffeeShop;
    }

    @Override
    public void run(){
            while (true) { // Barista continuously checking for and preparing orders.
                String order = coffeeShop.prepareOrder();
                //System.out.println("Order " + order + " prepared successfully");
                System.out.println(Thread.currentThread().getName() + " prepared " + order);
            }
    }
}
