public class Main {
    public static void main(String[] args) {

        int numberOfBaristas = 3; // A limited number of baristas
        int numberOfCustomers = 10; // More customers than baristas
        int queueCapacity = 5; // Coffee shop can hold a limited number of orders

        CoffeeShop coffeeShop = new CoffeeShop(queueCapacity);

        // Create and start barista threads
        Thread[] baristas = new Thread[numberOfBaristas];
        for (int i = 0; i < numberOfBaristas; i++) {
            baristas[i] = new Thread(new Barista(coffeeShop), "Barista " + (i + 1));
            baristas[i].start();
        }

        // Create and start customer threads
        Thread[] customers = new Thread[numberOfCustomers];
        for (int i = 0; i < numberOfCustomers; i++) {
            customers[i] = new Thread(new Customer(coffeeShop,"Order " + (i+1)), "Customer " + (i + 1));
            customers[i].start();

            // Simulate staggered arrival of customers
            try {
                Thread.sleep(1000); // Customers arrive every 1000ms
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Wait for customers to finish placing orders
        for (Thread customer : customers) {
            try {
                customer.join(); // Wait for customer threads to finish
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("All customers have been served!");
    }
}