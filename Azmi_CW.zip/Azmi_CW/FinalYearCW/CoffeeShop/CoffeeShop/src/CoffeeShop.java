import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
public class CoffeeShop {
    private int capacity;
    private Queue<String> orderQueue = new LinkedList<>();
    private final Lock lock = new ReentrantLock();
    private final Condition notEmpty = lock.newCondition(); /*Not empty means the queue is full.
                                                            Then the producer: Customer cannot acquire the lock */
    private final Condition notFull = lock.newCondition(); /*Not full means the queue is empty.
                                                         Then the consumer: Barista cannot acquire the lock */
    public CoffeeShop(int capacity) {
        this.capacity = capacity;
    }

    // Producer: Customer adds an order to the queue
    public void placeOrder(String order) {
        lock.lock();
        try {
            while (orderQueue.size() >= capacity) {
               try{
                   //Queue is full, wait for the barista to prepare orders
                   notEmpty.await();
               }catch(InterruptedException e){
                   e.printStackTrace();
               }
            }
            // Order can be added since the queue is not full
            orderQueue.add(order);
            //Signalling the barista that an order is available
            notFull.signalAll();
        } finally {
            lock.unlock();
        }
    }

    //Consumer: Barista consumes an order and removes it from the queue
    public String prepareOrder(){
        lock.lock();
        try {
            while (orderQueue.size() == 0) {
                //Queue is empty, wait for the customer to place an order
                try {
                    notFull.await();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            // Queue is not empty so can accept the order
            String order = orderQueue.poll(); // Removes the top most order from the queue
            notEmpty.signalAll(); // Signalling the customer that space is available in the queue
            return order;
        } finally {
            lock.unlock();
        }
    }
}

