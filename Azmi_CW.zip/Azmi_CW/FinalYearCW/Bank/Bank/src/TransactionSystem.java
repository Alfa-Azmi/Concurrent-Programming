import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Manages bank accounts and handles thread-safe transactions
class TransactionSystem {
    private final Map<Integer, BankAccount> accounts = new HashMap<>();
    public TransactionSystem(List<BankAccount> accountList) {
        for (BankAccount account : accountList) {
            accounts.put(account.getAccountId(), account);
        }
    }
    public boolean transfer(int fromAccountId, int toAccountId, BigDecimal amount)
            throws InsufficientBalanceException, InvalidAmountException {
        if (!accounts.containsKey(fromAccountId) || !accounts.containsKey(toAccountId)) {
            throw new IllegalArgumentException("Invalid account IDs.");
        }

        BankAccount fromAccount = accounts.get(fromAccountId);
        BankAccount toAccount = accounts.get(toAccountId);

        // Lock accounts in a consistent order to prevent deadlocks
        BankAccount firstLock = fromAccountId < toAccountId ? fromAccount : toAccount;
        BankAccount secondLock = fromAccountId < toAccountId ? toAccount : fromAccount;

        firstLock.getWriteLock().lock();
        secondLock.getWriteLock().lock();
        try {
            fromAccount.withdraw(amount); //Withdraws the given amount from the account
            toAccount.deposit(amount);//Deposits the given amount to the account
            System.out.println(Thread.currentThread().getName() + ": " + "Transfers Rs."
                    + amount + " from Account " + fromAccountId + " to Account " + toAccountId);
            return true;
        } finally {
            secondLock.getWriteLock().unlock();
            firstLock.getWriteLock().unlock();
        }
    }
    public void reverseTransaction(int fromAccountID, int toAccountId, BigDecimal amount) {
        System.out.println("Reverse Transactions");
        try {
            transfer(toAccountId, fromAccountID, amount);
        } catch (InsufficientBalanceException e) {
            e.printStackTrace();
        } catch (InvalidAmountException e) {
            e.printStackTrace();
        }
    }
    public void printAccountBalances() {
        accounts.forEach((id, account) -> System.out.println(
                "Account ID: " + account.getAccountId() + ", Balance: Rs." + account.getBalance()));
    }
}
