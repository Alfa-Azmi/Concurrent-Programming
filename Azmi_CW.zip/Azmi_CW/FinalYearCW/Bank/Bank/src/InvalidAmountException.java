public class InvalidAmountException extends Throwable{
    public InvalidAmountException(String invalidAmountException) {
        super(invalidAmountException);
    }
}
