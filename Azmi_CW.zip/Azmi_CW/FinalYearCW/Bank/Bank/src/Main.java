import java.math.BigDecimal;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Initialize three bank accounts with initial balances and account IDs
        BankAccount account1 = new BankAccount(1, new BigDecimal(10000));
        BankAccount account2 = new BankAccount(2, new BigDecimal(20000));
        BankAccount account3 = new BankAccount(3, new BigDecimal(25000));

        // Initialize the transaction system with the created accounts
        TransactionSystem transactionSystem = new TransactionSystem(List.of(account1, account2, account3));

        Thread transfer1 = new Thread(() -> {
            try {
                transactionSystem.transfer(1, 2, new BigDecimal(200));
            } catch (InsufficientBalanceException | InvalidAmountException e) {
                e.printStackTrace();
            } catch (IllegalArgumentException e) {
                System.err.println("Transfer 1 failed: Invalid account IDs.");
            }
        }, "Transfer 1");

        Thread transfer2 = new Thread(() -> {
            try {
                transactionSystem.transfer(2, 3, new BigDecimal(5000));
            } catch (InsufficientBalanceException | InvalidAmountException e) {
                System.err.println("Transfer 2 failed: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.err.println("Transfer 2 failed: Invalid account IDs.");
            }
        }, "Transfer 2");

        Thread transfer3 = new Thread(() -> {
            try {
                transactionSystem.transfer(3, 1, new BigDecimal(3000));
            } catch (InsufficientBalanceException | InvalidAmountException e) {
                System.err.println("Transfer 3 failed: " + e.getMessage());
            } catch (IllegalArgumentException e) {
                System.err.println("Transfer 3 failed: Invalid account IDs.");
            }
        }, "Transfer 3");

        Thread printBalances = new Thread(() -> {
            System.out.println("Account Balances:");
            transactionSystem.printAccountBalances();
        });

        transfer1.start();
        transfer2.start();
        transfer3.start();

        // Wait for the transactions to complete
        try {
            transfer1.join();
            transfer2.join();
            transfer3.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // Start the thread to print account balances
        printBalances.start();

        try {
            printBalances.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //reverse a transaction in case of an error
        transactionSystem.reverseTransaction(1, 2,new BigDecimal(100));
        transactionSystem.printAccountBalances();

    }
}
