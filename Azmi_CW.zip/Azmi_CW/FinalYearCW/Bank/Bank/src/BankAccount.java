import java.math.BigDecimal;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

class BankAccount {
   private final int accountId;
    private BigDecimal balance; // Current balance of the account
    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock(true); // Fair locking
    private final Lock readLock = rwLock.readLock();
    private final Lock writeLock = rwLock.writeLock();

    public BankAccount(int accountId, BigDecimal initialBalance) {
        this.accountId = accountId;
        this.balance = initialBalance;
    }
    public int getAccountId() {
        return accountId;
    }
    public BigDecimal getBalance() {
        readLock.lock();
        try {
            return balance;
        } finally {
            readLock.unlock();
        }
    }
    public void deposit(BigDecimal amount) throws InvalidAmountException {
        writeLock.lock();
        try {
            if (amount.compareTo(BigDecimal.ZERO) > 0) {
                balance = balance.add(amount);
                System.out.println("Deposited Rs." +amount + " to Account " + accountId + " | New balance: Rs." + balance);
            } else {
                throw new InvalidAmountException("Deposit a valid amount. Amount cannot be zero");
            }
        } finally {
            writeLock.unlock();
        }
    }

    public void withdraw(BigDecimal amount) throws InsufficientBalanceException {
        writeLock.lock();
        try {
            if (amount.compareTo(BigDecimal.ZERO) > 0 && balance.compareTo(amount) >= 0) {
                balance = balance.subtract(amount);
                System.out.println("Withdraw Rs." +amount + " from Account " + accountId + " | New balance: Rs." + balance);
            } else {
                throw new InsufficientBalanceException("Insufficient funds or invalid amount.");
            }
        } finally {
            writeLock.unlock();
        }
    }

    public Lock getWriteLock() {
        return rwLock.writeLock();
    }
}