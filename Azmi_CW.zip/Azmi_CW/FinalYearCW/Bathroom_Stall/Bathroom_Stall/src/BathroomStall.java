import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;

public class BathroomStall {
    private final static int BATHROOM_STALLS = 6;
    private final static int NUM_EMPLOYEES = 100;
    private final Semaphore stalls;
    private final boolean[] status;

    public BathroomStall() {
        this.stalls = new Semaphore(BATHROOM_STALLS, true);
        this.status = new boolean[BATHROOM_STALLS];
    }

    public static void main(String[] args) {
        BathroomStall bathroom = new BathroomStall();
        for (int empId = 1; empId <= NUM_EMPLOYEES; empId++) {
            int finalEmpId = empId;
            new Thread(() -> {
                try {
                    Thread.sleep(ThreadLocalRandom.current().nextInt(100, 300)); // Simulating arrival time
                    bathroom.useBathroom(finalEmpId);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    System.err.printf("Employee %d was interrupted before entering the bathroom.%n", finalEmpId);
                }
            }).start();
        }
    }

    public void useBathroom(int empId) throws InterruptedException {
        int assignedStall = -1;
        try {
            log(String.format("Employee %d is waiting to occupy a stall.%n", empId));
            stalls.acquire();

            assignedStall = stallOccupied(empId);
            Thread.sleep(ThreadLocalRandom.current().nextInt(500, 1500)); // Simulating bathroom usage time
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log(String.format("Employee %d was interrupted while using the bathroom.%n", empId));
        } finally {
            if (assignedStall != -1) {
                stallVacate(empId, assignedStall);
            } else {
                stalls.release();
            }
        }
    }

    private synchronized int stallOccupied(int empId) {
        for (int i = 0; i < status.length; i++) {
            if (!status[i]) {
                status[i] = true;
                log(String.format("Employee %d has occupied stall number %d.%n", empId, i + 1));
                return i;
            }
        }
        return -1; // Should never reach here if semaphore works correctly
    }

    private synchronized void stallVacate(int empId, int stallId) {
        status[stallId] = false;
        log(String.format("Employee %d has exited stall %d. Number of remaining stalls: %d%n", empId, stallId + 1, stalls.availablePermits() + 1));
        stalls.release();
    }
    private synchronized void log(String message) {
        System.out.print(message);
    }
}
